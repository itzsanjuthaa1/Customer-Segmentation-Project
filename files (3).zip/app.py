"""
app.py — Customer Segmentation Dashboard
Run: streamlit run app.py
"""

import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import io

from customer_segmentation import (
    load_data, build_features, find_optimal_k, run_kmeans,
    pca_projection, label_segments, segment_analytics,
    compute_kpis, RECOMMENDATIONS, FEATURES,
)

# ─── Page Config ─────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Customer Segmentation Intelligence",
    page_icon="🎯",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─── Theme / CSS ──────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

html, body, [class*="css"] { font-family: 'Inter', sans-serif; }

.kpi-card {
    background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
    border: 1px solid #334155;
    border-radius: 12px;
    padding: 1.2rem 1.5rem;
    text-align: center;
}
.kpi-label { font-size: 0.72rem; color: #94a3b8; letter-spacing: 0.08em; text-transform: uppercase; margin-bottom: 4px; }
.kpi-value { font-size: 1.6rem; font-weight: 700; color: #f1f5f9; }
.kpi-sub   { font-size: 0.72rem; color: #64748b; margin-top: 2px; }

.segment-card {
    background: #0f172a;
    border: 1px solid #1e293b;
    border-left: 4px solid #3b82f6;
    border-radius: 10px;
    padding: 1rem 1.2rem;
    margin-bottom: 0.8rem;
}
.seg-title { font-size: 1rem; font-weight: 600; color: #f1f5f9; margin-bottom: 0.4rem; }
.seg-desc  { font-size: 0.82rem; color: #94a3b8; line-height: 1.5; }

div[data-testid="stSidebar"] { background: #0f172a; }
</style>
""", unsafe_allow_html=True)

PALETTE = ["#3b82f6", "#8b5cf6", "#10b981", "#f59e0b", "#ef4444",
           "#06b6d4", "#ec4899", "#84cc16"]

# ─── Data Loading (cached) ────────────────────────────────────────────────────
@st.cache_data(show_spinner="Running segmentation pipeline …")
def get_segmented_data():
    df = load_data("data/customer_dataset.csv")
    X_scaled, scaler = build_features(df)
    inertias, silhouettes, best_k = find_optimal_k(X_scaled)
    km, labels = run_kmeans(X_scaled, best_k)
    df["Cluster"] = labels
    coords = pca_projection(X_scaled)
    df["PCA_X"] = coords[:, 0]
    df["PCA_Y"] = coords[:, 1]
    df, cluster_map = label_segments(df)
    analytics = segment_analytics(df)
    kpis = compute_kpis(df)
    return df, analytics, kpis, inertias, silhouettes, best_k


df_full, analytics, kpis, inertias, silhouettes, best_k = get_segmented_data()
k_range = list(range(2, 11))

# ─── Sidebar Filters ─────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("### 🎯 Segmentation Dashboard")
    st.markdown("---")

    age_opts = ["All", "18–24", "25–34", "35–44", "45–54", "55+"]
    sel_age = st.selectbox("Age Group", age_opts)

    sel_gender = st.multiselect(
        "Gender", df_full["Gender"].unique().tolist(),
        default=df_full["Gender"].unique().tolist()
    )

    sel_region = st.multiselect(
        "Region", df_full["Region"].unique().tolist(),
        default=df_full["Region"].unique().tolist()
    )

    sel_category = st.multiselect(
        "Product Category",
        df_full["ProductCategoryPreference"].unique().tolist(),
        default=df_full["ProductCategoryPreference"].unique().tolist()
    )

    sel_segment = st.multiselect(
        "Segment", df_full["Segment"].unique().tolist(),
        default=df_full["Segment"].unique().tolist()
    )

    st.markdown("---")
    st.markdown("**Model Settings**")
    st.info(f"Optimal K = **{best_k}**  \nSilhouette = **{max(silhouettes):.4f}**")

# ─── Filter Logic ─────────────────────────────────────────────────────────────
df = df_full.copy()
age_bins = {"18–24": (18,24), "25–34": (25,34), "35–44": (35,44),
            "45–54": (45,54), "55+": (55,120)}
if sel_age != "All":
    lo, hi = age_bins[sel_age]
    df = df[df["Age"].between(lo, hi)]
df = df[df["Gender"].isin(sel_gender)]
df = df[df["Region"].isin(sel_region)]
df = df[df["ProductCategoryPreference"].isin(sel_category)]
df = df[df["Segment"].isin(sel_segment)]

# ─── Header ───────────────────────────────────────────────────────────────────
st.markdown("## 🎯 Customer Segmentation Intelligence Dashboard")
st.markdown(f"*Showing **{len(df):,}** of {len(df_full):,} customers · K-Means k={best_k}*")
st.markdown("---")

# ─── KPI Row ──────────────────────────────────────────────────────────────────
k1, k2, k3, k4, k5 = st.columns(5)
kpi_data = [
    (k1, "Total Customers",    f"{len(df):,}",          "filtered"),
    (k2, "Avg. Spending",      f"₹{df['TotalSpending'].mean():,.0f}",   "per customer"),
    (k3, "Avg. Annual Income", f"₹{df['AnnualIncome'].mean():,.0f}",    "per customer"),
    (k4, "Retention Rate",     f"{kpis['retention_rate']}%",            "tenure ≥ median"),
    (k5, "Top Revenue Segment", kpis['highest_rev_segment'][:18],       "by total spend"),
]
for col, label, value, sub in kpi_data:
    with col:
        st.markdown(f"""
        <div class="kpi-card">
            <div class="kpi-label">{label}</div>
            <div class="kpi-value">{value}</div>
            <div class="kpi-sub">{sub}</div>
        </div>""", unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)

# ─── Row 1: Cluster Distribution + Elbow ─────────────────────────────────────
c1, c2 = st.columns(2)

with c1:
    seg_counts = df["Segment"].value_counts().reset_index()
    seg_counts.columns = ["Segment", "Count"]
    fig = px.pie(
        seg_counts, names="Segment", values="Count",
        color_discrete_sequence=PALETTE,
        title="Customer Segment Distribution",
        hole=0.45,
    )
    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        font_color="#e2e8f0", margin=dict(t=40, b=0, l=0, r=0),
        legend=dict(font_size=11),
    )
    st.plotly_chart(fig, use_container_width=True)

with c2:
    fig2 = make_subplots(specs=[[{"secondary_y": True}]])
    fig2.add_trace(go.Scatter(
        x=k_range, y=inertias, name="Inertia",
        line=dict(color="#3b82f6", width=2.5),
        marker=dict(size=7),
    ), secondary_y=False)
    fig2.add_trace(go.Scatter(
        x=k_range, y=silhouettes, name="Silhouette",
        line=dict(color="#10b981", width=2.5, dash="dash"),
        marker=dict(size=7),
    ), secondary_y=True)
    fig2.add_vline(x=best_k, line_dash="dot", line_color="#f59e0b",
                   annotation_text=f"  Best K={best_k}", annotation_font_color="#f59e0b")
    fig2.update_layout(
        title="Elbow Method & Silhouette Analysis",
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        font_color="#e2e8f0", margin=dict(t=40, b=0, l=0, r=0),
        legend=dict(font_size=11),
    )
    fig2.update_xaxes(title_text="Number of Clusters (K)", gridcolor="#1e293b")
    fig2.update_yaxes(title_text="Inertia", secondary_y=False, gridcolor="#1e293b")
    fig2.update_yaxes(title_text="Silhouette Score", secondary_y=True)
    st.plotly_chart(fig2, use_container_width=True)

# ─── Row 2: Scatter Plot ──────────────────────────────────────────────────────
fig3 = px.scatter(
    df, x="PCA_X", y="PCA_Y", color="Segment",
    hover_data=["Age", "AnnualIncome", "TotalSpending", "CustomerTenure"],
    title="Customer Segmentation — PCA Projection",
    color_discrete_sequence=PALETTE,
    opacity=0.65,
)
fig3.update_traces(marker=dict(size=5))
fig3.update_layout(
    paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
    font_color="#e2e8f0", margin=dict(t=40, b=0),
    xaxis=dict(gridcolor="#1e293b", title="Principal Component 1"),
    yaxis=dict(gridcolor="#1e293b", title="Principal Component 2"),
)
st.plotly_chart(fig3, use_container_width=True)

# ─── Row 3: Revenue + Income vs Spending ─────────────────────────────────────
c3, c4 = st.columns(2)

with c3:
    rev = df.groupby("Segment")["TotalSpending"].sum().reset_index()
    rev.columns = ["Segment", "Revenue"]
    rev = rev.sort_values("Revenue", ascending=True)
    fig4 = px.bar(
        rev, x="Revenue", y="Segment", orientation="h",
        color="Segment", color_discrete_sequence=PALETTE,
        title="Total Revenue by Segment",
        text=rev["Revenue"].apply(lambda x: f"₹{x/1e6:.1f}M"),
    )
    fig4.update_layout(
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        font_color="#e2e8f0", margin=dict(t=40, b=0), showlegend=False,
        xaxis=dict(gridcolor="#1e293b"),
    )
    fig4.update_traces(textposition="outside")
    st.plotly_chart(fig4, use_container_width=True)

with c4:
    fig5 = px.scatter(
        df.sample(min(1500, len(df)), random_state=1),
        x="AnnualIncome", y="TotalSpending",
        color="Segment", size="PurchaseFrequency",
        color_discrete_sequence=PALETTE,
        title="Income vs. Spending",
        opacity=0.7,
        size_max=14,
    )
    fig5.update_layout(
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        font_color="#e2e8f0", margin=dict(t=40, b=0),
        xaxis=dict(gridcolor="#1e293b"),
        yaxis=dict(gridcolor="#1e293b"),
    )
    st.plotly_chart(fig5, use_container_width=True)

# ─── Row 4: Age Distribution + Regional Breakdown ────────────────────────────
c5, c6 = st.columns(2)

with c5:
    fig6 = px.histogram(
        df, x="Age", color="Segment", nbins=30,
        color_discrete_sequence=PALETTE,
        title="Age Distribution by Segment",
        barmode="overlay", opacity=0.75,
    )
    fig6.update_layout(
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        font_color="#e2e8f0", margin=dict(t=40, b=0),
        xaxis=dict(gridcolor="#1e293b"),
        yaxis=dict(gridcolor="#1e293b"),
    )
    st.plotly_chart(fig6, use_container_width=True)

with c6:
    region_seg = (
        df.groupby(["Region", "Segment"]).size().reset_index(name="Count")
    )
    fig7 = px.bar(
        region_seg, x="Region", y="Count", color="Segment",
        color_discrete_sequence=PALETTE,
        title="Regional Customer Breakdown",
        barmode="stack",
    )
    fig7.update_layout(
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        font_color="#e2e8f0", margin=dict(t=40, b=0),
        xaxis=dict(gridcolor="#1e293b"),
        yaxis=dict(gridcolor="#1e293b"),
    )
    st.plotly_chart(fig7, use_container_width=True)

# ─── Row 5: Product Preference Heatmap ───────────────────────────────────────
cat_seg = (
    df.groupby(["ProductCategoryPreference", "Segment"])
    .size().reset_index(name="Count")
)
pivot = cat_seg.pivot(
    index="ProductCategoryPreference",
    columns="Segment",
    values="Count",
).fillna(0)

fig8 = px.imshow(
    pivot,
    color_continuous_scale="Blues",
    title="Product Category Preference by Segment",
    aspect="auto",
    text_auto=True,
)
fig8.update_layout(
    paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
    font_color="#e2e8f0", margin=dict(t=40, b=0),
)
st.plotly_chart(fig8, use_container_width=True)

# ─── Segment Profiles & Recommendations ──────────────────────────────────────
st.markdown("---")
st.markdown("## 📋 Segment Profiles & Business Recommendations")

for segment, info in RECOMMENDATIONS.items():
    if segment not in df["Segment"].unique():
        continue
    with st.expander(f"{segment}", expanded=False):
        st.markdown(f"**Profile:** {info['profile']}")
        st.markdown("**Recommended Actions:**")
        for s in info["strategies"]:
            st.markdown(f"- {s}")

# ─── Segment Summary Table ────────────────────────────────────────────────────
st.markdown("---")
st.markdown("## 📊 Segment Analytics Summary")

display_analytics = analytics.copy()
display_analytics["AvgIncome"] = display_analytics["AvgIncome"].apply(lambda x: f"₹{x:,.0f}")
display_analytics["AvgSpending"] = display_analytics["AvgSpending"].apply(lambda x: f"₹{x:,.0f}")
display_analytics["TotalRevenue"] = display_analytics["TotalRevenue"].apply(lambda x: f"₹{x/1e6:.1f}M")
st.dataframe(display_analytics, use_container_width=True, hide_index=True)

# ─── Export Section ───────────────────────────────────────────────────────────
st.markdown("---")
st.markdown("## ⬇️ Export Data")

col_e1, col_e2, col_e3 = st.columns(3)

with col_e1:
    csv_full = df.to_csv(index=False).encode("utf-8")
    st.download_button(
        "📥 Download Filtered Data (CSV)",
        csv_full, "filtered_customers.csv", "text/csv",
        use_container_width=True,
    )

with col_e2:
    csv_summary = analytics.to_csv(index=False).encode("utf-8")
    st.download_button(
        "📊 Download Segment Summary (CSV)",
        csv_summary, "segment_summary.csv", "text/csv",
        use_container_width=True,
    )

with col_e3:
    # Build a text report
    report_lines = ["CUSTOMER SEGMENTATION REPORT\n", "=" * 50 + "\n"]
    for _, row in analytics.iterrows():
        report_lines.append(f"\nSegment: {row['Segment']}")
        report_lines.append(f"  Customers   : {row['CustomerCount']:,}")
        report_lines.append(f"  Avg Income  : ₹{row['AvgIncome']:,.0f}")
        report_lines.append(f"  Avg Spending: ₹{row['AvgSpending']:,.0f}")
        report_lines.append(f"  Revenue Share: {row['RevenueShare%']}%")
        if row["Segment"] in RECOMMENDATIONS:
            report_lines.append("  Strategies:")
            for s in RECOMMENDATIONS[row["Segment"]]["strategies"]:
                report_lines.append(f"    • {s}")
    report_text = "\n".join(report_lines).encode("utf-8")
    st.download_button(
        "📄 Download Full Report (TXT)",
        report_text, "segmentation_report.txt", "text/plain",
        use_container_width=True,
    )

st.markdown("---")
st.markdown(
    "<div style='text-align:center;color:#475569;font-size:0.8rem;'>"
    "Built with Python · Scikit-learn · Plotly · Streamlit &nbsp;|&nbsp; B.Tech IT Portfolio Project"
    "</div>",
    unsafe_allow_html=True,
)
