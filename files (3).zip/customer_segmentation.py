"""
customer_segmentation.py
========================
Customer Segmentation using K-Means Clustering
B.Tech IT Portfolio Project

Author  : [Your Name]
Stack   : Python · Pandas · NumPy · Scikit-learn · Plotly · Streamlit
"""

# ── Imports ──────────────────────────────────────────────────────────────────
import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.decomposition import PCA

# ── 1. Load & Validate Data ───────────────────────────────────────────────────

def load_data(path: str = "data/customer_dataset.csv") -> pd.DataFrame:
    df = pd.read_csv(path)
    required = [
        "CustomerID", "Age", "AnnualIncome", "PurchaseFrequency",
        "AverageOrderValue", "TotalSpending", "CustomerTenure",
        "OnlinePurchaseRatio",
    ]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Missing columns: {missing}")
    df.dropna(inplace=True)
    return df


# ── 2. Feature Engineering ────────────────────────────────────────────────────

FEATURES = [
    "Age",
    "AnnualIncome",
    "PurchaseFrequency",
    "AverageOrderValue",
    "TotalSpending",
    "CustomerTenure",
    "OnlinePurchaseRatio",
]


def build_features(df: pd.DataFrame) -> tuple[np.ndarray, StandardScaler]:
    """Return scaled feature matrix and fitted scaler."""
    X = df[FEATURES].values
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    return X_scaled, scaler


# ── 3. Optimal K via Elbow + Silhouette ──────────────────────────────────────

def find_optimal_k(
    X_scaled: np.ndarray,
    k_range: range = range(2, 11),
) -> tuple[list[float], list[float], int]:
    """
    Returns inertias, silhouette scores, and recommended K.
    Recommendation = highest silhouette score.
    """
    inertias, silhouettes = [], []
    for k in k_range:
        km = KMeans(n_clusters=k, random_state=42, n_init=10)
        labels = km.fit_predict(X_scaled)
        inertias.append(km.inertia_)
        silhouettes.append(silhouette_score(X_scaled, labels))

    best_k = list(k_range)[int(np.argmax(silhouettes))]
    return inertias, silhouettes, best_k


# ── 4. Clustering ─────────────────────────────────────────────────────────────

def run_kmeans(X_scaled: np.ndarray, k: int) -> tuple[KMeans, np.ndarray]:
    km = KMeans(n_clusters=k, random_state=42, n_init=20, max_iter=500)
    labels = km.fit_predict(X_scaled)
    return km, labels


# ── 5. 2-D Projection for Scatter Plots ──────────────────────────────────────

def pca_projection(X_scaled: np.ndarray) -> np.ndarray:
    pca = PCA(n_components=2, random_state=42)
    return pca.fit_transform(X_scaled)


# ── 6. Segment Labelling ──────────────────────────────────────────────────────

SEGMENT_NAMES = {
    "high_spender":   "💎 Premium Buyers",
    "loyal_mid":      "🤝 Loyal Mid-Tier",
    "young_active":   "🚀 Young Actives",
    "budget":         "💡 Value Seekers",
    "at_risk":        "⚠️  At-Risk Customers",
}


def label_segments(df: pd.DataFrame) -> pd.DataFrame:
    """
    Assign a human-readable segment name to each cluster based on
    cluster centroid characteristics (income, spending, frequency, tenure).
    This is a heuristic mapping — adjust thresholds to fit your data.
    """
    df = df.copy()

    stats = (
        df.groupby("Cluster")[
            ["AnnualIncome", "TotalSpending", "PurchaseFrequency", "CustomerTenure"]
        ]
        .mean()
    )

    spending_rank = stats["TotalSpending"].rank()
    income_rank   = stats["AnnualIncome"].rank()
    freq_rank     = stats["PurchaseFrequency"].rank()
    tenure_rank   = stats["CustomerTenure"].rank()

    n = len(stats)
    high  = n * 0.7
    low   = n * 0.3

    def assign(cluster_id):
        s  = spending_rank[cluster_id]
        inc = income_rank[cluster_id]
        f  = freq_rank[cluster_id]
        t  = tenure_rank[cluster_id]
        if s >= high and inc >= high:
            return SEGMENT_NAMES["high_spender"]
        if t >= high and f >= high:
            return SEGMENT_NAMES["loyal_mid"]
        if f >= high and inc <= low:
            return SEGMENT_NAMES["young_active"]
        if s <= low and inc <= low:
            return SEGMENT_NAMES["budget"]
        return SEGMENT_NAMES["at_risk"]

    cluster_map = {cid: assign(cid) for cid in stats.index}
    df["Segment"] = df["Cluster"].map(cluster_map)
    return df, cluster_map


# ── 7. Segment Analytics ──────────────────────────────────────────────────────

def segment_analytics(df: pd.DataFrame) -> pd.DataFrame:
    agg = (
        df.groupby("Segment")
        .agg(
            CustomerCount=("CustomerID", "count"),
            AvgAge=("Age", "mean"),
            AvgIncome=("AnnualIncome", "mean"),
            AvgSpending=("TotalSpending", "mean"),
            AvgOrderValue=("AverageOrderValue", "mean"),
            AvgFrequency=("PurchaseFrequency", "mean"),
            AvgTenure=("CustomerTenure", "mean"),
            AvgOnlineRatio=("OnlinePurchaseRatio", "mean"),
            TotalRevenue=("TotalSpending", "sum"),
        )
        .reset_index()
    )
    agg["RevenueShare%"] = (agg["TotalRevenue"] / agg["TotalRevenue"].sum() * 100).round(1)
    for col in ["AvgAge", "AvgIncome", "AvgSpending", "AvgOrderValue", "AvgFrequency",
                "AvgTenure", "AvgOnlineRatio"]:
        agg[col] = agg[col].round(1)
    return agg.sort_values("TotalRevenue", ascending=False).reset_index(drop=True)


# ── 8. Business Recommendations ──────────────────────────────────────────────

RECOMMENDATIONS = {
    "💎 Premium Buyers": {
        "profile": (
            "High-income, high-spending customers who purchase premium products regularly. "
            "They have significant tenure and balanced online/offline behaviour."
        ),
        "strategies": [
            "🎯 Launch an exclusive VIP loyalty programme with priority support and early access.",
            "📦 Offer curated subscription boxes or premium bundles at a slight discount.",
            "🤝 Assign a dedicated account manager for personalised relationship marketing.",
            "📧 Quarterly luxury-lifestyle newsletters with exclusive member-only offers.",
        ],
    },
    "🤝 Loyal Mid-Tier": {
        "profile": (
            "Long-tenure customers with consistent mid-range spending and high purchase frequency. "
            "They are the backbone of revenue stability."
        ),
        "strategies": [
            "⬆️  Design tiered rewards that nudge them toward premium categories.",
            "🎁 Birthday/anniversary personalised gifts to deepen emotional loyalty.",
            "🔄 Cross-sell complementary product categories based on purchase history.",
            "📱 Mobile-first engagement campaigns — this group responds well to push notifications.",
        ],
    },
    "🚀 Young Actives": {
        "profile": (
            "Young, digitally-native customers with high purchase frequency but moderate income. "
            "They are trendsetters with strong online engagement."
        ),
        "strategies": [
            "📱 Invest in social-commerce and influencer partnerships targeting their age group.",
            "💳 Introduce a buy-now-pay-later option to reduce friction on larger purchases.",
            "🏆 Gamified loyalty points that reward frequency over order size.",
            "🎓 Student and early-career discount bundles to increase AOV over time.",
        ],
    },
    "💡 Value Seekers": {
        "profile": (
            "Budget-conscious customers with low income and infrequent purchases. "
            "Price sensitivity is the dominant decision driver."
        ),
        "strategies": [
            "🏷️  Flash sales and time-limited coupons to drive purchase urgency.",
            "📦 Bundle essentials at a 'value pack' price to increase basket size.",
            "🔔 Price-drop alerts and wishlist notifications to convert browsers.",
            "🤲 Referral programmes — a free or discounted item for every new customer referred.",
        ],
    },
    "⚠️  At-Risk Customers": {
        "profile": (
            "Previously active customers whose purchase frequency has declined significantly. "
            "Intervention is critical to prevent churn."
        ),
        "strategies": [
            "💌 Win-back email sequence: 'We miss you' + personalised 20 % discount.",
            "📊 Conduct NPS/satisfaction surveys to identify specific pain points.",
            "🛒 Abandoned-cart reminders with a limited-time incentive to complete purchase.",
            "📞 Proactive outreach from customer success team for high-value at-risk accounts.",
        ],
    },
}


# ── 9. KPI Summary ────────────────────────────────────────────────────────────

def compute_kpis(df: pd.DataFrame) -> dict:
    retention = round(
        (df["CustomerTenure"] >= df["CustomerTenure"].median()).mean() * 100, 1
    )
    top_segment = (
        df.groupby("Segment")["TotalSpending"].sum().idxmax()
        if "Segment" in df.columns else "N/A"
    )
    return {
        "total_customers":    len(df),
        "avg_spending":       round(df["TotalSpending"].mean(), 2),
        "avg_income":         round(df["AnnualIncome"].mean(), 2),
        "retention_rate":     retention,
        "highest_rev_segment": top_segment,
    }


# ── 10. Pipeline ──────────────────────────────────────────────────────────────

def run_pipeline(csv_path: str = "data/customer_dataset.csv"):
    print("=" * 60)
    print("  Customer Segmentation ML Pipeline")
    print("=" * 60)

    print("\n[1/6] Loading data …")
    df = load_data(csv_path)
    print(f"      {len(df):,} records loaded.")

    print("\n[2/6] Building feature matrix …")
    X_scaled, scaler = build_features(df)

    print("\n[3/6] Finding optimal K (2–10) …")
    inertias, silhouettes, best_k = find_optimal_k(X_scaled)
    print(f"      Optimal K = {best_k}  (silhouette = {max(silhouettes):.4f})")

    print(f"\n[4/6] Fitting K-Means (k={best_k}) …")
    km, labels = run_kmeans(X_scaled, best_k)
    df["Cluster"] = labels
    df["PCA_X"], df["PCA_Y"] = pca_projection(X_scaled).T
    sil = silhouette_score(X_scaled, labels)
    print(f"      Inertia = {km.inertia_:,.1f}  |  Silhouette = {sil:.4f}")

    print("\n[5/6] Labelling segments …")
    df, cluster_map = label_segments(df)
    for k, v in cluster_map.items():
        n = (df["Cluster"] == k).sum()
        print(f"      Cluster {k} → {v}  ({n:,} customers)")

    print("\n[6/6] Computing analytics …")
    analytics = segment_analytics(df)
    kpis = compute_kpis(df)

    print("\n── KPIs ──────────────────────────────────────────────────")
    for key, val in kpis.items():
        print(f"   {key:<25} {val}")

    print("\n── Segment Summary ───────────────────────────────────────")
    print(analytics[["Segment", "CustomerCount", "AvgSpending", "RevenueShare%"]].to_string(index=False))

    # Save results
    out_path = csv_path.replace("customer_dataset.csv", "customer_segmented.csv")
    df.to_csv(out_path, index=False)
    print(f"\n✅  Segmented data saved → {out_path}")

    return df, analytics, kpis, inertias, silhouettes, best_k, cluster_map


if __name__ == "__main__":
    run_pipeline()
